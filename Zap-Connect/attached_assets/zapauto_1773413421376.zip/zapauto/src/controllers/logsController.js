/**
 * ZapAuto - Controller de Logs
 */

const db = require('../config/database');

/**
 * Renderiza a página de logs
 */
function getLogs(req, res) {
  // Últimos 200 logs
  const logs = db.prepare(`
    SELECT * FROM logs ORDER BY created_at DESC LIMIT 200
  `).all();

  res.render('logs', {
    title: 'Logs em Tempo Real',
    logs,
    username: req.session.username
  });
}

/**
 * Limpa todos os logs (via AJAX)
 */
function clearLogs(req, res) {
  db.prepare('DELETE FROM logs').run();
  res.json({ ok: true });
}

module.exports = { getLogs, clearLogs };
