/**
 * ZapAuto - Controller do WhatsApp
 * Gerencia a tela de conexão e envio manual
 */

const whatsappService = require('../services/whatsappService');

/**
 * Renderiza a tela de conexão do WhatsApp
 */
function getConnection(req, res) {
  const waStatus = whatsappService.getStatus();
  res.render('connection', {
    title: 'Conexão WhatsApp',
    waStatus,
    username: req.session.username
  });
}

/**
 * Inicia a conexão do WhatsApp (via POST ou chamada da interface)
 */
function connect(req, res) {
  whatsappService.initialize();
  res.json({ ok: true, message: 'Iniciando conexão...' });
}

/**
 * Desconecta o WhatsApp
 */
async function disconnect(req, res) {
  await whatsappService.destroy();
  res.json({ ok: true, message: 'Desconectado com sucesso.' });
}

/**
 * Renderiza a tela de envio manual
 */
function getSend(req, res) {
  res.render('send', {
    title: 'Envio Manual',
    username: req.session.username,
    flash: req.session.flash || null
  });
  delete req.session.flash;
}

/**
 * Processa o formulário de envio manual
 */
async function postSend(req, res) {
  const { number, message } = req.body;

  if (!number || !message) {
    req.session.flash = { type: 'danger', msg: 'Número e mensagem são obrigatórios.' };
    return res.redirect('/send');
  }

  try {
    await whatsappService.sendMessage(number, message);
    req.session.flash = { type: 'success', msg: `Mensagem enviada para ${number} com sucesso!` };
  } catch (err) {
    req.session.flash = { type: 'danger', msg: `Erro ao enviar: ${err.message}` };
  }

  res.redirect('/send');
}

/**
 * Retorna o status atual via JSON (para polling/socket)
 */
function getStatus(req, res) {
  res.json(whatsappService.getStatus());
}

module.exports = { getConnection, connect, disconnect, getSend, postSend, getStatus };
