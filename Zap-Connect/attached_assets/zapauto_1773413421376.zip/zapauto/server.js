/**
 * ZapAuto - Servidor Principal
 * Ponto de entrada da aplicação
 */

require('dotenv').config();
const express    = require('express');
const session    = require('express-session');
const path       = require('path');
const http       = require('http');
const { Server } = require('socket.io');

// Inicializa o banco de dados antes de qualquer coisa
const db = require('./src/config/database');

// Importa as rotas
const routes = require('./src/routes/index');

// Importa o serviço do WhatsApp
const whatsappService = require('./src/services/whatsappService');

const app    = express();
const server = http.createServer(app);

// Configura Socket.IO para comunicação em tempo real
const io = new Server(server, {
  cors: { origin: '*' }
});

// Disponibiliza o io globalmente para outros módulos usarem
global.io = io;

// ─── Middlewares ─────────────────────────────────────────────

// Parse de JSON e formulários
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Arquivos estáticos (CSS, JS público)
app.use(express.static(path.join(__dirname, 'public')));

// Configuração de sessão com armazenamento em SQLite
const SQLiteStore = require('connect-sqlite3')(session);
app.use(session({
  store: new SQLiteStore({ db: 'sessions.db', dir: './data' }),
  secret: process.env.SESSION_SECRET || 'zapauto_secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 1000 * 60 * 60 * 8 // 8 horas
  }
}));

// ─── Template Engine ──────────────────────────────────────────
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'src/views'));

// ─── Rotas ────────────────────────────────────────────────────
app.use('/', routes);

// ─── Socket.IO ────────────────────────────────────────────────
io.on('connection', (socket) => {
  console.log(`[SOCKET] Cliente conectado: ${socket.id}`);

  // Envia o status atual do WhatsApp ao cliente que acabou de conectar
  const status = whatsappService.getStatus();
  socket.emit('whatsapp:status', status);

  socket.on('disconnect', () => {
    console.log(`[SOCKET] Cliente desconectado: ${socket.id}`);
  });
});

// ─── Tratamento de erros globais ──────────────────────────────
app.use((err, req, res, next) => {
  console.error('[ERRO] Erro não tratado:', err);
  res.status(500).render('error', {
    title: 'Erro interno',
    message: err.message || 'Ocorreu um erro inesperado.'
  });
});

// ─── Inicia o servidor ────────────────────────────────────────
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`\n🤖 ZapAuto iniciado com sucesso!`);
  console.log(`🌐 Painel: http://localhost:${PORT}`);
  console.log(`👤 Login: admin / admin123\n`);

  // Inicializa o cliente WhatsApp após o servidor subir
  whatsappService.initialize();
});

// Trata desligamento limpo do processo
process.on('SIGINT', async () => {
  console.log('\n[SISTEMA] Encerrando ZapAuto...');
  await whatsappService.destroy();
  process.exit(0);
});
