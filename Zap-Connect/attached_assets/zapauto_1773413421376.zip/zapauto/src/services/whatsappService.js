/**
 * ZapAuto - Serviço do WhatsApp
 * Gerencia o cliente whatsapp-web.js, QR Code, conexão e fila de mensagens
 */

const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode                = require('qrcode');
const path                  = require('path');
const autoReplyService      = require('./autoReplyService');
const db                    = require('../config/database');

// ─── Estado interno do serviço ────────────────────────────────
let client       = null;
let currentQR    = null;
let status       = 'disconnected'; // disconnected | waiting_qr | qr_generated | connected
let connectedNumber = null;
let isInitializing  = false;

// Fila de mensagens para evitar flood
const messageQueue = [];
let processingQueue = false;

// ─── Funções auxiliares ───────────────────────────────────────

/**
 * Registra uma linha de log no banco e emite via Socket.IO
 */
function addLog(level, message) {
  try {
    db.prepare('INSERT INTO logs (level, message) VALUES (?, ?)').run(level, message);
    if (global.io) {
      global.io.emit('log:new', { level, message, time: new Date().toISOString() });
    }
    console.log(`[${level.toUpperCase()}] ${message}`);
  } catch (err) {
    console.error('[LOG ERROR]', err);
  }
}

/**
 * Atualiza o status e emite via Socket.IO
 */
function setStatus(newStatus, extra = {}) {
  status = newStatus;
  if (global.io) {
    global.io.emit('whatsapp:status', { status, connectedNumber, ...extra });
  }
}

/**
 * Delay aleatório entre DELAY_MIN e DELAY_MAX ms
 */
function randomDelay() {
  const min = parseInt(process.env.DELAY_MIN) || 2000;
  const max = parseInt(process.env.DELAY_MAX) || 5000;
  return new Promise(resolve => setTimeout(resolve, Math.floor(Math.random() * (max - min + 1)) + min));
}

/**
 * Incrementa estatísticas do dia
 */
function incrementStat(field) {
  const today = new Date().toISOString().slice(0, 10);
  db.prepare(`
    INSERT INTO stats (date, ${field}) VALUES (?, 1)
    ON CONFLICT(date) DO UPDATE SET ${field} = ${field} + 1
  `).run(today);
}

// ─── Fila de mensagens ────────────────────────────────────────

/**
 * Adiciona uma tarefa à fila e processa se não estiver processando
 */
function enqueue(task) {
  messageQueue.push(task);
  if (!processingQueue) processQueue();
}

/**
 * Processa a fila de mensagens uma a uma
 */
async function processQueue() {
  processingQueue = true;
  while (messageQueue.length > 0) {
    const task = messageQueue.shift();
    try {
      await task();
    } catch (err) {
      addLog('error', `Erro ao processar fila: ${err.message}`);
    }
  }
  processingQueue = false;
}

// ─── Manipulador de mensagens recebidas ───────────────────────

/**
 * Processa uma mensagem recebida pelo WhatsApp
 */
async function handleMessage(msg) {
  try {
    // Ignora mensagens do próprio bot
    if (msg.fromMe) return;

    // Ignora mensagens de status (broadcast)
    if (msg.from === 'status@broadcast') return;

    const contact   = await msg.getContact();
    const chat      = await msg.getChat();
    const isGroup   = chat.isGroup;
    const fromName  = contact.pushname || contact.name || msg.from.replace('@c.us', '');
    const fromNum   = msg.from.replace('@c.us', '');
    const body      = msg.body || '';

    addLog('info', `📨 Mensagem recebida de ${fromName} (${fromNum}): ${body.substring(0, 80)}`);

    // Marca como lida automaticamente
    await chat.sendSeen();

    // Incrementa estatística de entrada
    incrementStat('messages_in');

    // Busca a regra correspondente
    const matchResult = autoReplyService.findRule(body, isGroup);

    // Salva no histórico
    const insertedMsg = db.prepare(`
      INSERT INTO messages (from_number, from_name, body, is_group, triggered_rule, auto_replied)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(
      fromNum,
      fromName,
      body,
      isGroup ? 1 : 0,
      matchResult ? matchResult.rule.id : null,
      matchResult ? 1 : 0
    );

    // Emite a mensagem ao painel em tempo real
    if (global.io) {
      global.io.emit('message:new', {
        id:           insertedMsg.lastInsertRowid,
        from_number:  fromNum,
        from_name:    fromName,
        body:         body,
        is_group:     isGroup,
        auto_replied: matchResult ? 1 : 0,
        received_at:  new Date().toISOString()
      });
    }

    // Se encontrou uma regra, enfileira a resposta
    if (matchResult) {
      enqueue(async () => {
        try {
          // Delay humano aleatório
          await randomDelay();

          // Substitui variáveis na resposta
          const response = matchResult.response
            .replace(/{nome}/gi, fromName)
            .replace(/{numero}/gi, fromNum);

          await msg.reply(response);
          incrementStat('messages_out');

          addLog('success', `✅ Resposta automática enviada para ${fromName}: ${response.substring(0, 60)}`);

          if (global.io) {
            global.io.emit('stat:update');
          }
        } catch (err) {
          addLog('error', `Falha ao enviar resposta para ${fromNum}: ${err.message}`);
        }
      });
    }
  } catch (err) {
    addLog('error', `Erro ao processar mensagem: ${err.message}`);
  }
}

// ─── Inicialização do cliente ─────────────────────────────────

/**
 * Inicializa o cliente do WhatsApp com LocalAuth
 */
function initialize() {
  if (isInitializing || (client && status === 'connected')) {
    addLog('warn', 'WhatsApp já está inicializado ou conectando.');
    return;
  }

  isInitializing = true;
  currentQR      = null;
  setStatus('waiting_qr');
  addLog('info', '🔄 Inicializando cliente WhatsApp...');

  client = new Client({
    authStrategy: new LocalAuth({
      clientId: 'zapauto',
      dataPath: path.join(__dirname, '../../sessions')
    }),
    puppeteer: {
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
        '--no-zygote',
        '--disable-gpu'
      ]
    },
    // Aguarda mais antes de considerar autenticado (evita erros de timing)
    authTimeoutMs: 60000
  });

  // ─── Eventos do cliente ──────────────────────────────────────

  // QR Code gerado
  client.on('qr', async (qr) => {
    try {
      isInitializing = false;
      currentQR = await qrcode.toDataURL(qr);
      setStatus('qr_generated', { qr: currentQR });
      addLog('info', '📱 QR Code gerado! Escaneie com seu WhatsApp.');
    } catch (err) {
      addLog('error', `Erro ao gerar QR Code: ${err.message}`);
    }
  });

  // Carregando (sessão salva encontrada)
  client.on('loading_screen', (percent, message) => {
    addLog('info', `⏳ Carregando sessão... ${percent}% - ${message}`);
  });

  // Autenticado com sucesso
  client.on('authenticated', () => {
    addLog('success', '🔐 Autenticado com sucesso!');
    setStatus('authenticated');
  });

  // Pronto para uso
  client.on('ready', async () => {
    try {
      isInitializing   = false;
      const info       = client.info;
      connectedNumber  = info.wid.user;
      currentQR        = null;
      setStatus('connected');
      addLog('success', `✅ WhatsApp conectado! Número: ${connectedNumber}`);
    } catch (err) {
      addLog('error', `Erro ao obter info do cliente: ${err.message}`);
    }
  });

  // Mensagem recebida
  client.on('message', handleMessage);

  // Desconectado
  client.on('disconnected', (reason) => {
    connectedNumber = null;
    currentQR       = null;
    setStatus('disconnected');
    addLog('warn', `⚠️ WhatsApp desconectado: ${reason}`);

    // Tenta reconectar após 10 segundos
    setTimeout(() => {
      addLog('info', '🔄 Tentando reconectar automaticamente...');
      initialize();
    }, 10000);
  });

  // Erro de autenticação
  client.on('auth_failure', (msg) => {
    isInitializing = false;
    setStatus('disconnected');
    addLog('error', `❌ Falha de autenticação: ${msg}`);
  });

  // Inicia o cliente
  client.initialize().catch(err => {
    isInitializing = false;
    setStatus('disconnected');
    addLog('error', `❌ Erro ao inicializar: ${err.message}`);
  });
}

/**
 * Destrói o cliente atual (para desconectar manualmente)
 */
async function destroy() {
  if (client) {
    try {
      await client.destroy();
    } catch (err) {
      // Ignora erros ao destruir
    }
    client          = null;
    currentQR       = null;
    connectedNumber = null;
    isInitializing  = false;
    setStatus('disconnected');
    addLog('info', '🔌 Cliente WhatsApp destruído.');
  }
}

/**
 * Envia uma mensagem diretamente (usado no envio manual)
 */
async function sendMessage(number, message) {
  if (!client || status !== 'connected') {
    throw new Error('WhatsApp não está conectado.');
  }

  // Formata o número (remove +, espaços e traços)
  const formatted = number.replace(/\D/g, '') + '@c.us';

  await client.sendMessage(formatted, message);
  incrementStat('messages_out');
  addLog('success', `📤 Mensagem manual enviada para ${number}`);
}

/**
 * Retorna o estado atual do serviço
 */
function getStatus() {
  return {
    status,
    connectedNumber,
    qr: currentQR
  };
}

module.exports = {
  initialize,
  destroy,
  sendMessage,
  getStatus
};
