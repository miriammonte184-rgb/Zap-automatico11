/**
 * ZapAuto - Middleware de Autenticação
 * Protege todas as rotas do painel
 */

/**
 * Verifica se o usuário está logado na sessão.
 * Se não, redireciona para /login.
 */
function requireAuth(req, res, next) {
  if (req.session && req.session.loggedIn) {
    return next();
  }
  return res.redirect('/login');
}

module.exports = { requireAuth };
