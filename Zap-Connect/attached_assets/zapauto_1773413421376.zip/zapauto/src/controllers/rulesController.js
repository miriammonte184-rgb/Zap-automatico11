/**
 * ZapAuto - Controller de Regras
 * CRUD completo de regras de resposta automática
 */

const db = require('../config/database');

/**
 * Lista todas as regras (ordenadas por prioridade)
 */
function getRules(req, res) {
  const rules = db.prepare(`
    SELECT * FROM rules ORDER BY is_default ASC, priority DESC, id ASC
  `).all();

  res.render('rules', {
    title: 'Regras Automáticas',
    rules,
    username: req.session.username,
    flash: req.session.flash || null
  });

  // Limpa o flash após exibir
  delete req.session.flash;
}

/**
 * Cria uma nova regra
 */
function createRule(req, res) {
  const {
    keywords, match_type, response,
    scope, active, priority, is_default
  } = req.body;

  // Validação básica
  if (!is_default && (!keywords || !keywords.trim())) {
    req.session.flash = { type: 'danger', msg: 'Palavras-chave são obrigatórias.' };
    return res.redirect('/rules');
  }
  if (!response || !response.trim()) {
    req.session.flash = { type: 'danger', msg: 'Resposta não pode ser vazia.' };
    return res.redirect('/rules');
  }

  // Se for regra padrão, desativa as outras regras padrão existentes
  if (is_default === '1') {
    db.prepare('UPDATE rules SET is_default = 0 WHERE is_default = 1').run();
  }

  db.prepare(`
    INSERT INTO rules (keywords, match_type, response, scope, active, priority, is_default)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(
    keywords      || '',
    match_type    || 'contains',
    response,
    scope         || 'all',
    active        === '1' ? 1 : 0,
    parseInt(priority) || 0,
    is_default    === '1' ? 1 : 0
  );

  req.session.flash = { type: 'success', msg: 'Regra criada com sucesso!' };
  res.redirect('/rules');
}

/**
 * Retorna uma regra específica em JSON (para o modal de edição)
 */
function getRule(req, res) {
  const rule = db.prepare('SELECT * FROM rules WHERE id = ?').get(req.params.id);
  if (!rule) return res.status(404).json({ error: 'Regra não encontrada.' });
  res.json(rule);
}

/**
 * Atualiza uma regra existente
 */
function updateRule(req, res) {
  const {
    keywords, match_type, response,
    scope, active, priority, is_default
  } = req.body;
  const { id } = req.params;

  if (!response || !response.trim()) {
    req.session.flash = { type: 'danger', msg: 'Resposta não pode ser vazia.' };
    return res.redirect('/rules');
  }

  // Se for regra padrão, remove o padrão das outras
  if (is_default === '1') {
    db.prepare('UPDATE rules SET is_default = 0 WHERE is_default = 1 AND id != ?').run(id);
  }

  db.prepare(`
    UPDATE rules SET
      keywords   = ?,
      match_type = ?,
      response   = ?,
      scope      = ?,
      active     = ?,
      priority   = ?,
      is_default = ?,
      updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(
    keywords      || '',
    match_type    || 'contains',
    response,
    scope         || 'all',
    active        === '1' ? 1 : 0,
    parseInt(priority) || 0,
    is_default    === '1' ? 1 : 0,
    id
  );

  req.session.flash = { type: 'success', msg: 'Regra atualizada com sucesso!' };
  res.redirect('/rules');
}

/**
 * Exclui uma regra
 */
function deleteRule(req, res) {
  db.prepare('DELETE FROM rules WHERE id = ?').run(req.params.id);
  req.session.flash = { type: 'success', msg: 'Regra excluída com sucesso!' };
  res.redirect('/rules');
}

/**
 * Alterna o status ativo/inativo de uma regra (chamada via AJAX)
 */
function toggleRule(req, res) {
  const rule = db.prepare('SELECT active FROM rules WHERE id = ?').get(req.params.id);
  if (!rule) return res.status(404).json({ error: 'Regra não encontrada.' });

  const newActive = rule.active ? 0 : 1;
  db.prepare('UPDATE rules SET active = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
    .run(newActive, req.params.id);

  res.json({ active: newActive });
}

module.exports = { getRules, createRule, getRule, updateRule, deleteRule, toggleRule };
