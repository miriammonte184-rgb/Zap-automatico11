# 🤖 ZapAuto — Painel de Respostas Automáticas para WhatsApp

Sistema completo de automação de WhatsApp com painel web, respostas automáticas,
histórico de mensagens e logs em tempo real.

---

## 📋 Pré-requisitos

- **Node.js** v18 ou superior → https://nodejs.org
- **npm** (já vem com o Node.js)
- **Google Chrome** ou **Chromium** instalado no sistema (necessário para o Puppeteer)
- Sistema operacional: Linux, macOS ou Windows

---

## 🚀 Instalação Passo a Passo

### 1. Entre na pasta do projeto

```bash
cd zapauto
```

### 2. Instale as dependências

```bash
npm install
```

> ⏳ Isso pode demorar alguns minutos (o Puppeteer faz download do Chromium automaticamente).

### 3. Configure o arquivo `.env` (opcional)

O arquivo `.env` já vem pré-configurado. Edite se quiser mudar a porta ou credenciais:

```env
PORT=3000
SESSION_SECRET=zapauto_secret_2024_troque_isso
ADMIN_USER=admin
ADMIN_PASS=admin123
DELAY_MIN=2000
DELAY_MAX=5000
```

### 4. Inicie o servidor

**Modo desenvolvimento (reinicia ao salvar):**
```bash
npm run dev
```

**Modo produção:**
```bash
npm start
```

### 5. Acesse o painel

Abra seu navegador em: **http://localhost:3000**

Login padrão: `admin` / `admin123`

---

## 📱 Como Conectar o WhatsApp

1. No painel, clique em **"Conexão WhatsApp"** no menu lateral
2. Clique no botão **"Conectar ao WhatsApp"**
3. Aguarde o QR Code aparecer (pode levar 10-30 segundos)
4. No seu celular, abra o WhatsApp
5. Acesse **Menu ⋮ → Dispositivos Conectados → Conectar um dispositivo**
6. Aponte a câmera para o QR Code na tela
7. Aguarde a confirmação ✅

> 💡 **A sessão é salva automaticamente!** Na próxima vez que iniciar o servidor,
> o WhatsApp reconecta sozinho sem precisar escanear o QR Code novamente.

---

## ⚙️ Funcionalidades

### 🏠 Dashboard
- Status em tempo real do bot
- Contador de mensagens recebidas e respostas enviadas hoje
- Histórico das últimas 50 mensagens (atualiza em tempo real)

### ⚡ Respostas Automáticas
- Crie quantas regras quiser com palavras-chave
- **Tipos de match:** Contém / Começa com / Exata
- **Escopos:** Todos / Somente privado / Somente grupos
- Variáveis disponíveis: `{nome}` e `{numero}`
- **Regra padrão (fallback)** para quando nenhuma keyword bater
- Ativar/desativar regras com um clique
- Sistema de prioridades

### 📤 Envio Manual
- Envie mensagens para qualquer número no formato `+5511999999999`

### 📊 Logs em Tempo Real
- Terminal com logs coloridos por nível (info, success, warn, error)
- Atualização em tempo real via WebSocket
- Botão para limpar logs

---

## 🛡️ Dicas de Segurança e Risco de Banimento

### ⚠️ RISCOS DE BANIMENTO

O uso de `whatsapp-web.js` **viola os Termos de Serviço do WhatsApp**.
Use com responsabilidade. Riscos aumentam quando você:

- Envia mensagens em massa para números desconhecidos
- Responde muito rápido (por isso existe o delay de 2-5s)
- Usa o bot com um número novo
- Recebe muitas denúncias de spam

### ✅ BOAS PRÁTICAS PARA EVITAR BAN

1. **Use um número antigo** com histórico de conversas
2. **Nunca faça spam** — use apenas com contatos que já te conhecem
3. **Mantenha o delay** — o delay aleatório de 2-5s já está configurado
4. **Evite mensagens idênticas** para muitas pessoas
5. **Não envie mídias** em massa
6. **Número de negócio** — considere usar o WhatsApp Business oficial para uso comercial
7. **Faça backup da pasta `sessions/`** para não perder a autenticação

### 🔒 SEGURANÇA DO PAINEL

1. **Troque as credenciais padrão** no arquivo `.env`:
   ```env
   ADMIN_USER=seu_usuario
   ADMIN_PASS=sua_senha_forte
   ```

2. **Troque o SESSION_SECRET** por uma string aleatória longa

3. **Não exponha o painel na internet** sem HTTPS e autenticação adicional

4. **Use um firewall** para restringir acesso à porta 3000

---

## 📁 Estrutura do Projeto

```
zapauto/
├── src/
│   ├── config/database.js        # Configuração SQLite
│   ├── controllers/              # Lógica de cada rota
│   ├── middleware/authMiddleware.js
│   ├── models/                   # (reservado para expansão)
│   ├── services/
│   │   ├── whatsappService.js    # Cliente WhatsApp + fila
│   │   └── autoReplyService.js   # Motor de regras
│   ├── routes/index.js
│   └── views/                    # Templates EJS
├── public/                       # CSS e JS estáticos
├── sessions/                     # Sessão do WhatsApp (auto-gerado)
├── data/                         # Banco SQLite (auto-gerado)
├── .env
├── package.json
└── server.js
```

---

## 🐛 Solução de Problemas

### "Cannot find module 'better-sqlite3'"
```bash
npm install better-sqlite3 --build-from-source
```

### "Error: Failed to launch the browser process"
Instale as dependências do Chromium no Linux:
```bash
sudo apt-get install -y libgbm-dev libasound2 libatk-bridge2.0-0 \
  libatk1.0-0 libcups2 libdrm2 libgdk-pixbuf2.0-0 libgtk-3-0 \
  libnspr4 libnss3 libxcomposite1 libxdamage1 libxfixes3 \
  libxrandr2 libxss1 xdg-utils
```

### QR Code não aparece
- Aguarde até 30 segundos
- Verifique os logs na página de Logs
- Tente desconectar e reconectar

### Sessão expirou
- Delete a pasta `sessions/` e reconecte
- O WhatsApp desconecta sessões inativas após ~14 dias

---

## 📞 Suporte

- Documentação whatsapp-web.js: https://docs.wwebjs.dev
- Issues: verifique os logs no painel antes de reportar

---

**ZapAuto v1.0** — Construído com ❤️ usando Node.js + whatsapp-web.js
