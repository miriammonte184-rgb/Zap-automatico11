/**
 * ZapAuto - Configuração do Banco de Dados
 * Usa better-sqlite3 (síncrono e simples)
 */

const Database = require('better-sqlite3');
const path     = require('path');
const fs       = require('fs');

// Garante que o diretório /data existe
const dataDir = path.join(__dirname, '../../data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Abre (ou cria) o arquivo do banco
const db = new Database(path.join(dataDir, 'zapauto.db'), {
  // verbose: console.log // Descomente para depurar queries SQL
});

// Ativa WAL mode para melhor performance
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ─── Criação das tabelas ──────────────────────────────────────

db.exec(`
  -- Tabela de regras de resposta automática
  CREATE TABLE IF NOT EXISTS rules (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    keywords    TEXT    NOT NULL,          -- palavras-chave separadas por vírgula
    match_type  TEXT    NOT NULL DEFAULT 'contains', -- contains | starts_with | exact
    response    TEXT    NOT NULL,          -- texto da resposta automática
    scope       TEXT    NOT NULL DEFAULT 'all', -- all | private | groups
    active      INTEGER NOT NULL DEFAULT 1, -- 1=ativo, 0=inativo
    priority    INTEGER NOT NULL DEFAULT 0, -- maior número = maior prioridade
    is_default  INTEGER NOT NULL DEFAULT 0, -- 1=regra padrão (fallback)
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Tabela de mensagens recebidas (histórico)
  CREATE TABLE IF NOT EXISTS messages (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    from_number   TEXT    NOT NULL,
    from_name     TEXT,
    body          TEXT    NOT NULL,
    is_group      INTEGER NOT NULL DEFAULT 0,
    triggered_rule INTEGER,               -- ID da regra disparada (NULL se nenhuma)
    auto_replied  INTEGER NOT NULL DEFAULT 0,
    received_at   DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Tabela de logs do sistema
  CREATE TABLE IF NOT EXISTS logs (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    level      TEXT NOT NULL DEFAULT 'info', -- info | warn | error | success
    message    TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Tabela de estatísticas diárias
  CREATE TABLE IF NOT EXISTS stats (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    date            TEXT NOT NULL UNIQUE, -- YYYY-MM-DD
    messages_in     INTEGER NOT NULL DEFAULT 0,
    messages_out    INTEGER NOT NULL DEFAULT 0
  );
`);

// ─── Insere regras de exemplo se o banco estiver vazio ────────
const rulesCount = db.prepare('SELECT COUNT(*) as c FROM rules').get();
if (rulesCount.c === 0) {
  // Regra de boas-vindas
  db.prepare(`
    INSERT INTO rules (keywords, match_type, response, scope, active, priority)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(
    'oi,olá,ola,bom dia,boa tarde,boa noite,hi,hello',
    'contains',
    'Olá, {nome}! 👋 Seja bem-vindo(a)!\n\nComo posso te ajudar hoje? 😊',
    'all',
    1,
    10
  );

  // Regra padrão (fallback)
  db.prepare(`
    INSERT INTO rules (keywords, match_type, response, scope, active, priority, is_default)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(
    '',
    'contains',
    'Obrigado pela mensagem, {nome}! 🤖\n\nVou verificar e te respondo em breve. ⏳',
    'all',
    1,
    0,
    1
  );

  console.log('[DB] Regras de exemplo criadas com sucesso!');
}

console.log('[DB] Banco de dados inicializado com sucesso!');

module.exports = db;
