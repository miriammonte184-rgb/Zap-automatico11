/**
 * ZapAuto - Rotas
 * Define todas as rotas da aplicação
 */

const express     = require('express');
const router      = express.Router();

const { requireAuth }       = require('../middleware/authMiddleware');
const authController        = require('../controllers/authController');
const dashboardController   = require('../controllers/dashboardController');
const rulesController       = require('../controllers/rulesController');
const whatsappController    = require('../controllers/whatsappController');
const logsController        = require('../controllers/logsController');

// ─── Rotas públicas (sem autenticação) ───────────────────────
router.get( '/login',  authController.getLogin);
router.post('/login',  authController.postLogin);
router.get( '/logout', authController.logout);

// ─── Rotas protegidas ─────────────────────────────────────────

// Dashboard (página inicial)
router.get('/', requireAuth, dashboardController.getDashboard);

// Conexão WhatsApp
router.get( '/connection',    requireAuth, whatsappController.getConnection);
router.post('/api/connect',   requireAuth, whatsappController.connect);
router.post('/api/disconnect',requireAuth, whatsappController.disconnect);
router.get( '/api/status',    requireAuth, whatsappController.getStatus);

// Regras de resposta automática
router.get(   '/rules',         requireAuth, rulesController.getRules);
router.post(  '/rules',         requireAuth, rulesController.createRule);
router.get(   '/rules/:id',     requireAuth, rulesController.getRule);
router.post(  '/rules/:id',     requireAuth, rulesController.updateRule);
router.post(  '/rules/:id/delete', requireAuth, rulesController.deleteRule);
router.post(  '/rules/:id/toggle', requireAuth, rulesController.toggleRule);

// Envio manual
router.get( '/send', requireAuth, whatsappController.getSend);
router.post('/send', requireAuth, whatsappController.postSend);

// Logs
router.get( '/logs',       requireAuth, logsController.getLogs);
router.post('/logs/clear', requireAuth, logsController.clearLogs);

module.exports = router;
