/**
 * ZapAuto - Controller de Autenticação
 */

const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASS || 'admin123';

/**
 * Renderiza a página de login
 */
function getLogin(req, res) {
  if (req.session.loggedIn) return res.redirect('/');
  res.render('auth/login', { title: 'Login', error: null });
}

/**
 * Processa o formulário de login
 */
function postLogin(req, res) {
  const { username, password } = req.body;

  if (username === ADMIN_USER && password === ADMIN_PASS) {
    req.session.loggedIn  = true;
    req.session.username  = username;
    return res.redirect('/');
  }

  res.render('auth/login', {
    title: 'Login',
    error: 'Usuário ou senha inválidos.'
  });
}

/**
 * Encerra a sessão e redireciona para login
 */
function logout(req, res) {
  req.session.destroy(() => {
    res.redirect('/login');
  });
}

module.exports = { getLogin, postLogin, logout };
