/**
 * ZapAuto - Serviço de Respostas Automáticas
 * Processa regras e encontra a resposta correta para cada mensagem
 */

const db = require('../config/database');

/**
 * Normaliza uma string: remove acentos, converte para minúsculo e trim
 */
function normalize(str) {
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
}

/**
 * Verifica se um texto bate com uma keyword dado um tipo de match
 * @param {string} text     - Mensagem recebida
 * @param {string} keyword  - Palavra-chave da regra
 * @param {string} matchType - contains | starts_with | exact
 */
function matchKeyword(text, keyword, matchType) {
  const normalText = normalize(text);
  const normalKey  = normalize(keyword);

  switch (matchType) {
    case 'exact':
      return normalText === normalKey;
    case 'starts_with':
      return normalText.startsWith(normalKey);
    case 'contains':
    default:
      return normalText.includes(normalKey);
  }
}

/**
 * Busca a regra que melhor corresponde à mensagem recebida
 * @param {string}  text    - Corpo da mensagem
 * @param {boolean} isGroup - Se veio de grupo ou não
 * @returns {{ rule, response } | null}
 */
function findRule(text, isGroup) {
  // Busca todas as regras ativas, ordenadas por prioridade (maior primeiro)
  const rules = db.prepare(`
    SELECT * FROM rules
    WHERE active = 1 AND is_default = 0
    ORDER BY priority DESC
  `).all();

  for (const rule of rules) {
    // Verifica o escopo (privado / grupo / todos)
    if (rule.scope === 'private' && isGroup)  continue;
    if (rule.scope === 'groups'  && !isGroup) continue;

    // Divide as keywords por vírgula e testa cada uma
    const keywords = rule.keywords.split(',').map(k => k.trim()).filter(Boolean);

    for (const keyword of keywords) {
      if (keyword && matchKeyword(text, keyword, rule.match_type)) {
        return { rule, response: rule.response };
      }
    }
  }

  // Nenhuma regra bateu — tenta regra padrão
  const defaultRule = db.prepare(`
    SELECT * FROM rules
    WHERE active = 1 AND is_default = 1
    LIMIT 1
  `).get();

  if (defaultRule) {
    // Verifica escopo da regra padrão também
    if (defaultRule.scope === 'private' && isGroup)  return null;
    if (defaultRule.scope === 'groups'  && !isGroup) return null;

    return { rule: defaultRule, response: defaultRule.response };
  }

  return null;
}

module.exports = { findRule };
