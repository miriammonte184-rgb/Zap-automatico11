/**
 * ZapAuto - JavaScript do Painel (compartilhado em todas as páginas)
 * Gerencia a conexão Socket.IO e o badge de status da navbar
 */

// Conecta ao Socket.IO
const socket = io();

// ─── Utilitários ──────────────────────────────────────────────

/**
 * Escapa HTML para evitar XSS ao inserir conteúdo dinamicamente
 */
function escHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g,  '&amp;')
    .replace(/</g,  '&lt;')
    .replace(/>/g,  '&gt;')
    .replace(/"/g,  '&quot;')
    .replace(/'/g,  '&#039;');
}

// ─── Badge de status na Navbar ────────────────────────────────

const statusMap = {
  disconnected: { label: 'Desconectado',    css: 'bg-danger' },
  waiting_qr:   { label: 'Conectando...',   css: 'bg-warning text-dark badge-pulse' },
  qr_generated: { label: 'QR Gerado',        css: 'bg-info text-dark badge-pulse' },
  authenticated:{ label: 'Autenticando...', css: 'bg-warning text-dark badge-pulse' },
  connected:    { label: 'Conectado ✅',     css: 'bg-success' }
};

/**
 * Atualiza o badge de status da navbar
 */
socket.on('whatsapp:status', function(data) {
  const badge = document.getElementById('navbar-status');
  if (!badge) return;

  const s = statusMap[data.status] || { label: data.status, css: 'bg-secondary' };
  badge.className = `badge ${s.css}`;
  badge.innerHTML = `<i class="bi bi-circle-fill me-1"></i> ${s.label}`;
});

// ─── Evento de conexão ────────────────────────────────────────

socket.on('connect', function() {
  console.log('[ZapAuto] Socket.IO conectado ao servidor');
});

socket.on('disconnect', function() {
  console.log('[ZapAuto] Socket.IO desconectado do servidor');
  const badge = document.getElementById('navbar-status');
  if (badge) {
    badge.className = 'badge bg-secondary';
    badge.innerHTML = '<i class="bi bi-wifi-off me-1"></i> Sem conexão';
  }
});
