/**
 * ZapAuto - Controller do Dashboard
 */

const db             = require('../config/database');
const whatsappService = require('../services/whatsappService');

/**
 * Renderiza o dashboard com estatísticas e histórico de mensagens
 */
function getDashboard(req, res) {
  const today = new Date().toISOString().slice(0, 10);

  // Estatísticas do dia
  const stats = db.prepare(`
    SELECT * FROM stats WHERE date = ?
  `).get(today) || { messages_in: 0, messages_out: 0 };

  // Últimas 50 mensagens recebidas
  const messages = db.prepare(`
    SELECT * FROM messages
    ORDER BY received_at DESC
    LIMIT 50
  `).all();

  // Status atual do WhatsApp
  const waStatus = whatsappService.getStatus();

  res.render('dashboard', {
    title: 'Dashboard',
    stats,
    messages,
    waStatus,
    username: req.session.username
  });
}

module.exports = { getDashboard };
